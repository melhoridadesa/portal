<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">

<title>Portal Melhor Idade SA</title>


<link href="portal/midia/css/bootstrap.min.css" rel="stylesheet">


<link href="portal/midia/css/freelancer.css" rel="stylesheet">


<link href="portal/midia/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
<link href="http://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">


<!-- jQuery -->
<script src="portal/midia/js/jquery.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="portal/midia/js/bootstrap.min.js"></script>

<!-- Plugin JavaScript -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
<script src="portal/midia/js/classie.js"></script>
<script src="portal/midia/js/cbpAnimatedHeader.js"></script>

<!-- Contact Form JavaScript -->
<script src="portal/midia/js/jqBootstrapValidation.js"></script>
<script src="portal/midia/js/contact_me.js"></script>

<!-- Custom Theme JavaScript -->
<script src="portal/midia/js/freelancer.js"></script>
