<!DOCTYPE html>
<html lang="pt-br">

<head>

<?php
include_once("includes/head.php");
?>

</head>

<body id="page-top" class="index">
<?php
    require_once("includes/menu.php");
    if ($pagina=="portal/index.php"){
      $pagina = "principal.php";
    }
?>

<?php
  require_once($pagina);
  if($pagina == "principal.php"){
    require_once("contato.php");
  }
  require_once("includes/rodape.php");
?>







</body>

</html>
