/* inserir dados na tabela de CONTATO */

insert into contato(nome, email, assunto, mensagem) values('idoso1', 'idoso1@bol.com.br', 'reclamacao', 'Estou insatifeito com os servicos prestados');

insert into contato(nome, email, assunto, mensagem) values('idoso2', 'idoso2@bol.com.br', 'puxacao de saco', 'Estou extremamente satifeito com os servicos prestados');

insert into contato(nome, email, assunto, mensagem) values('idoso3', 'idoso3@bol.com.br', 'puxacao de saco', 'Estou extremamente satifeito com os servicos prestados');

insert into contato(nome, email, assunto, mensagem) values('idoso4', 'idoso4@bol.com.br', 'puxacao de saco', 'Estou extremamente satifeito com os servicos prestados');



/*inserir dados na tabela de CONTEUDO*/
insert into conteudo(titulo, texto, data, usuario) values('Nossa ONG', 'Esta ong da melhor idade visa acompanhar programadores com experiencia', '2016-04-28', 1);
insert into conteudo(titulo, texto, data, usuario) values('Nossa ONG 2', 'Esta ong da pior idade visa acompanhar programadores com experiencia', '2016-04-29', 1);
insert into conteudo(titulo, texto, data, usuario) values('Nossa ONG 3', 'Esta ong da mais ou menos idade visa acompanhar programadores com experiencia', '2016-04-28', 1);
insert into conteudo(titulo, texto, data, usuario) values('Nossa ONG 4', 'Esta ong da melhor idade visa acompanhar programadores com experiencia', '2016-04-27', 1);
insert into conteudo(titulo, texto, data, usuario) values('Nossa ONG 5', 'Esta ong da melhor idade visa acompanhar programadores com experiencia', '2016-04-20', 1);
insert into conteudo(titulo, texto, data, usuario) values('Nossa ONG 6', 'Esta ong da melhor idade visa acompanhar programadores com experiencia', '2016-04-15', 1);

